// Change text content dynamically
document.getElementById('change-text-btn').addEventListener('click', function() {
  const textElement = document.getElementById('dynamic-text');
  textElement.textContent = 'You clicked the button! 🎉';
});

// Modify CSS styles via JavaScript
document.getElementById('change-style-btn').addEventListener('click', function() {
  const textElement = document.getElementById('dynamic-text');
  textElement.style.color = 'green';
  textElement.style.fontSize = '30px';
});

// Add or remove an element dynamically
document.getElementById('toggle-box-btn').addEventListener('click', function() {
  const container = document.getElementById('container');
  let box = document.getElementById('dynamic-box');

  if (box) {
    container.removeChild(box);
  } else {
    box = document.createElement('div');
    box.id = 'dynamic-box';
    container.appendChild(box);
  }
});
